classdef fitcnet
    %FITCNET converts patternnet object to compatible form with ELT
    %   This class embedds a patternnet object to enable compatibility with
    %   the Ensemble Learning Toolbox.
    
    properties
        net % Embedded Network
        classes % Original classes
    end
    
    methods
        function obj = fitcnet(net, X, y)
            %FITCNET trains a neural network in compatible form
            %   Detailed explanation goes here
            obj.classes = unique(y,'stable');
            X = X';
            y = full(ind2vec(grp2idx(y)'));
            obj.net = train(net,X,y);
        end
        
        function y = predict(obj,X)
            %PREDICT predicts output for new input X
            %   Classify a matrix of inputs
            [~,idx] = max(obj.net(X'));
            y = obj.classes(idx);
        end
    end
end

