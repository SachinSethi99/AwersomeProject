function perform = train_MNISTnn(nodeVec,train_params,train_labels,test_params,test_labels)

perform = [];
