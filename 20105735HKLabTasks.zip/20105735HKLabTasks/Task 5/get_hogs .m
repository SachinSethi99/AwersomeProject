% Description: convert an image to grayscale and extract HOG
% features from patches of size 16*16 pixels
%
% Inputs:
% im: an image
% 
% Outputs:
% h: an array containing all the HOG features for the image
% 
% Notes: just a simple wrapper function for the built-in
% extractHOGFeatures() function that makes sure the conversion to
% grayscale happens first, and that the 'CellSize' input is set
%
function [hog_16x16] = get_hogs(im)
queryimage1 =rgb2gray(im);
[hog_16x16, vis16x16] = extractHOGFeatures(queryimage1,'CellSize',[16 16]);
end