% Description: reproduce the imgradientxy() function behaviour (using
% 'Prewitt') for yourself.
%
% Inputs: im: an image
% 
% Outputs: Gx an array of horizontal local gradient estimates in double
% precision Gy an array of vertical local gradient estimates in double
% precision
% 
% Notes: you might want to start by calling imfilter() to do the
% convolutions for you, before then trying to replace them for yourself, or
% you might prefer to jump straight into the convolutions. (Note if you do
% use it that imfilter() will return the same data types you pass it, and
% so you'll lose information if you pass it uint8s.) A full implementation
% should add padding around the image (by copying the closest pixel
% values)
function [Gx, Gy] = my_imgradientxy(im)

[Gx, Gy] = imgradientxy(test, 'Prewitt')
    
    % write your code on the lines below:
    
    
    
end