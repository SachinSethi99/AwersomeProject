% Description: generate estimates of the fraction of vertical and
% horizontal edge pixels in an image by calling imgradientxy to compute
% local gradients in each direction and thresholding the magnitudes in the
% two resulting matrices
%
% Inputs: im: an image
% 
% Outputs: edges: array containing the fraction of all gradient magnitudes
% above the threshold in the horizontal direction (inside edges(1)) and the
% fraction of all gradient magnitudes above the threshold in the vertical
% direction (inside edges(2))
% 
function edges = get_edges(Ix,Iy)
    
    f1 = mean(mean(Ix));
    f2 = mean(mean(Iy));
    edges = [f1 f2];
    
    % write your code on the lines below:
    
    

end