% Description: reproduce the im2gray() function behaviour for
% yourself (including some simple Inputs/Outputs comments, below)
%
% Inputs:
% im: an image
% 
% Outputs: 
% im_g: a greyscale image consisting of uint8 values
% 
% Notes: the function should return uint8 values (matching what is passed
% in) but you'll get rounding errors if you perform the conversion
% calculation with uint8 values, so some recasting is needed here
%
function im_g = my_im2gray(im)

    im_g = [];

    % write your code on the lines below:
    
    
    
end